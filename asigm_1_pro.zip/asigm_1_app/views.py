from re import template
from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse, Http404
from .models import Person
from django.template import loader
from django.core.urlresolvers import reverse

# Create your views here.

# def index(request):
#     response = HttpResponse()
#     response.write("This is my first Django application")
#     return response

def index(request):
    latest_person_list = Person.objects.order_by('id')[:5]
    template = loader.get_template('asigm_1_app/index.html')
    context = {
        'latest_person_list': latest_person_list,
    }
    # return HttpResponse (output)
    return HttpResponse(template.render(context, request))

def detail(request, person_id):
    try:
        person = Person.objects.get(pk=person_id)
    except Person.Doesnotexist:
        raise Http404("Person does not exist")
    return render(request, 'asigm_1_app/detail.html', {'person': person})

def results(request, person_id):
    response = "You're looking at the information of person %s."
    return HttpResponse(response % person_id)

def vote(request, person_id):
    return HttpResponse("You're voting on person %s." % person_id)